#!/bin/bash
appDir=$(dirname "$0")
sudo "$appDir/contitool.sh" -d