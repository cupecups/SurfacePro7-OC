Have you tried [these steps](https://github.com/dokterdok/Continuity-Activation-Tool/wiki#cant-open-the-tool)?

Is there already an open topic for this issue?

Please include the following information.

- OS Version:
- Mac model:
- Dongle or replaced card?:
- Used dongle/card:

Your Issue:

Steps done to try to fix the issue:

